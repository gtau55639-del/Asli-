package id.smkn6garut.cbt

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.WindowManager
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebResourceRequest
import android.net.Uri
import android.os.Build
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback

/**
 * CBT SMKN 6 Garut UI integration shell.
 * The bundled HTML is a local interactive design prototype; it is NOT authenticated
 * against a school server until the official backend contract is supplied.
 */
class MainActivity : ComponentActivity() {
    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE
        )

        WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG)
        webView = WebView(this).apply {
            setBackgroundColor(android.graphics.Color.rgb(245, 247, 244))
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(
                    view: WebView?, request: WebResourceRequest?
                ): Boolean {
                    // The app is a bundled local UI; never navigate to an untrusted external page.
                    val uri: Uri = request?.url ?: return true
                    return uri.scheme != "file" || uri.host != null && uri.host != "android_asset"
                }

                override fun onReceivedError(
                    view: WebView?,
                    request: android.webkit.WebResourceRequest?,
                    error: android.webkit.WebResourceError?
                ) {
                    super.onReceivedError(view, request, error)
                    if (request?.isForMainFrame == true) {
                        Toast.makeText(this@MainActivity, "Tampilan lokal gagal dimuat. Coba buka ulang aplikasi.", Toast.LENGTH_LONG).show()
                    }
                }
            }
            webChromeClient = WebChromeClient()
            settings.apply {
                javaScriptEnabled = true // Needed for local page navigation and interactive question demo.
                domStorageEnabled = false
                // Android asset loading still works; arbitrary filesystem/content access stays off.
                allowFileAccess = false
                allowContentAccess = false
                allowFileAccessFromFileURLs = false
                allowUniversalAccessFromFileURLs = false
                mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) safeBrowsingEnabled = true
                saveFormData = false
                setSupportZoom(false)
                builtInZoomControls = false
                displayZoomControls = false
                javaScriptCanOpenWindowsAutomatically = false
                setSupportMultipleWindows(false)
            }
            loadUrl("file:///android_asset/index.html")
        }
        setContentView(webView)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                // HTML navigation is handled in-page. Avoid accidentally exiting an exam demo.
                webView.evaluateJavascript(
                    "(function(){var m=document.getElementById('modal');if(m&&m.classList.contains('show')){m.classList.remove('show');return 'modal';}var e=document.getElementById('exam');if(e&&e.classList.contains('active')){show('home');return 'home';}var l=document.getElementById('login');if(l&&l.classList.contains('active')){show('servers');return 'servers';}if(e&&document.getElementById('home')&&document.getElementById('home').classList.contains('active')){show('servers');return 'servers';}return 'exit';})()"
                ) { result ->
                    if (result == "\"exit\"") {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                    }
                }
            }
        })
    }

    override fun onPause() {
        if (::webView.isInitialized) webView.onPause()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        if (::webView.isInitialized) webView.onResume()
    }

    override fun onDestroy() {
        if (::webView.isInitialized) {
            webView.stopLoading()
            webView.loadUrl("about:blank")
            webView.removeAllViews()
            webView.destroy()
        }
        super.onDestroy()
    }
}
