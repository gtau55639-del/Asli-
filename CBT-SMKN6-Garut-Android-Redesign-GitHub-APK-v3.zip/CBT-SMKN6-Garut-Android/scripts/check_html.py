from pathlib import Path
import re
import sys

html_path = Path('app/src/main/assets/index.html')
if not html_path.is_file():
    sys.exit('ERROR: bundled HTML asset is missing')
html = html_path.read_text(encoding='utf-8')
required = [
    'id="splash"', 'id="servers"', 'id="login"', 'id="home"', 'id="exam"',
    'Lewati intro', "setTimeout(()=>{show('servers')},650)",
    'function renderQ()', 'function nextQ()', 'function prevQ()',
]
missing = [item for item in required if item not in html]
if missing:
    sys.exit('ERROR: required UI behavior missing: ' + ', '.join(missing))
scripts = re.findall(r'<script>(.*?)</script>', html, flags=re.S | re.I)
if not scripts:
    sys.exit('ERROR: no inline JavaScript found')
Path('/tmp/cbt-inline.js').write_text('\n'.join(scripts), encoding='utf-8')
print(f'HTML structure OK; {len(scripts)} inline script block(s), {len(html)} characters.')
