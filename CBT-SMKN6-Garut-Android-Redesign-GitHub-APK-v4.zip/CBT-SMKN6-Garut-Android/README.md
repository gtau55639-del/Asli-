# CBT SMK Negeri 6 Garut — Android UI Redesign (GitHub APK)

Proyek Android Kotlin yang mengemas UI HTML lokal ke dalam APK menggunakan WebView. Desain ini ditujukan untuk evaluasi antarmuka dan alur navigasi, bukan pengganti backend CBT sekolah.

## Perbaikan pada paket ini

- Splash intro tidak menunggu jaringan dan otomatis berpindah ke pemilihan server setelah sekitar 650 ms; tersedia tombol **Lewati intro**.
- HTML dibundel sebagai asset lokal, sehingga tampilan awal tidak perlu mengunduh halaman dari internet.
- Validasi struktur UI dan sintaks JavaScript dijalankan di GitHub Actions sebelum build.
- WebView menolak navigasi keluar dari asset lokal, menonaktifkan akses file/content umum, akses lintas-file, mixed content, popup, zoom, dan penyimpanan form; Safe Browsing diaktifkan pada Android 8.0+.
- `FLAG_SECURE` membantu memblokir screenshot/perekaman layar standar pada jendela aplikasi.
- Lifecycle WebView dijeda/dilanjutkan sesuai lifecycle Activity dan dibersihkan ketika Activity dihancurkan.
- Workflow CI membangun APK debug, memeriksa bahwa file APK tidak kosong, lalu mengunggah artifact.

## Pembaruan v4

- Ditambahkan logo resmi CBT SMK Negeri 6 Garut sebagai ikon aplikasi (adaptive icon + ikon bulat) dan pada layar splash/header.
- Tampilan WebView kini memakai padding window insets, sehingga konten tidak tertutup status bar/navigation bar pada Android 15 (targetSdk 35).
- Status bar palsu (09:41) dan catatan preview di luar bingkai dihapus pada tampilan HP.
- Splash tampil sekitar 1,8 detik (hanya berpindah otomatis bila masih di splash).
- Workflow juga menerbitkan APK ke **Releases**, sehingga bisa diunduh langsung tanpa artifact .zip.

## Batasan fungsional yang belum bisa diselesaikan tanpa backend resmi

- Pilihan server masih pilihan UI, bukan koneksi ke server sekolah.
- Login belum memverifikasi username/NIS, password, atau kode ujian. Jangan masukkan kredensial asli ke versi ini.
- Soal dan jawaban adalah data contoh; tidak ada penyimpanan jawaban ujian yang persisten atau pengiriman jawaban ke server.
- Timer pada layar adalah contoh visual, bukan timer ujian otoritatif.
- Re-authentication setelah aplikasi ditinggalkan belum diterapkan pada alur HTML ini.

Agar menjadi CBT online sungguhan, pengelola sekolah perlu memberikan alamat server/API resmi, skema autentikasi, format data soal/jawaban, aturan sesi, dan prosedur pemulihan koneksi. Jangan menebak endpoint atau memasukkan secret ke APK. Backend harus memvalidasi sesi, waktu ujian, akses soal, dan penerimaan jawaban di sisi server.

## Build APK melalui GitHub

1. Buat repository GitHub baru.
2. Ekstrak ZIP dan unggah **semua isi folder proyek ke root repository**, termasuk `.github/workflows/android.yml` dan `scripts/check_html.py`. Hapus/nonaktifkan workflow lama yang berisi `chmod +x gradlew` karena proyek ini tidak menyertakan file `gradlew`; workflow baru menggunakan Gradle 8.9 yang disiapkan di runner.
3. Buka tab **Actions**. Workflow berjalan saat push ke `main`/`master`, pull request, atau melalui `workflow_dispatch`.
4. Jika semua langkah berhasil, buka run workflow dan unduh artifact `cbt-smkn6garut-debug-apk`.

Artifact adalah **APK debug untuk pengujian**, bukan APK rilis bertanda tangan untuk distribusi publik. Workflow CI telah ditambahkan, tetapi build Android belum dapat dijalankan dalam lingkungan pembuatan ZIP ini karena Android SDK/Gradle lokal tidak tersedia. Status build final perlu dipastikan dari GitHub Actions.

## Keamanan

- `FLAG_SECURE` bukan perlindungan mutlak terhadap semua cara menyalin layar, kamera eksternal, atau perangkat yang dimodifikasi.
- Screen pinning biasa bukan kiosk lock yang kuat. Mode Lock Task memerlukan perangkat terkelola/Device Owner dan konfigurasi admin.
- Jangan menanam password admin, token rahasia permanen, atau private key ke APK.
- Gunakan hanya server dan data yang penggunaannya disetujui pengelola sekolah.

## Detail teknis

- Android application ID: `id.smkn6garut.cbt`
- `minSdk`: 23
- `targetSdk`: 35
- Java/Kotlin target: 17
- Android Gradle Plugin: 8.7.3
- Gradle CI: 8.9
