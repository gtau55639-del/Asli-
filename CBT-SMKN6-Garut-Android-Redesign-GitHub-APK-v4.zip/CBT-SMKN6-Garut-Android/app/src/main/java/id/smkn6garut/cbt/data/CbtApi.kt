package id.smkn6garut.cbt.data

import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.PUT
import retrofit2.http.Path
import retrofit2.http.POST
import java.util.concurrent.TimeUnit

data class HealthResponse(val status: String? = null, val message: String? = null)
data class SessionRequest(val participantCode: String, val password: String, val examCode: String)
data class SessionResponse(val sessionToken: String, val participantName: String? = null, val examId: String)
data class ExamResponse(val id: String, val title: String, val durationMinutes: Int, val questions: List<QuestionDto>)
data class QuestionDto(val id: String, val text: String, val options: List<String>)
data class AnswerRequest(val sessionToken: String, val answers: Map<String, Int>)
data class BasicResponse(val success: Boolean, val message: String? = null)

interface CbtApi {
    @GET("api/v1/health")
    suspend fun health(): HealthResponse

    @POST("api/v1/auth/session")
    suspend fun createSession(@Body request: SessionRequest): SessionResponse

    // Endpoint backend perlu memvalidasi ulang password untuk membuka kembali sesi terkunci.
    @POST("api/v1/auth/reauthenticate")
    suspend fun reauthenticate(@Body request: SessionRequest): SessionResponse

    @GET("api/v1/exams/{examId}")
    suspend fun getExam(@Path("examId") examId: String): ExamResponse

    @PUT("api/v1/exams/{examId}/answers")
    suspend fun submitAnswers(@Path("examId") examId: String, @Body request: AnswerRequest): BasicResponse
}

object ApiFactory {
    fun create(baseUrl: String, debug: Boolean): CbtApi {
        require(baseUrl.startsWith("https://") || (debug && (baseUrl.startsWith("http://10.0.2.2") || baseUrl.startsWith("http://localhost")))) {
            "Server harus menggunakan HTTPS."
        }
        val logging = HttpLoggingInterceptor().apply {
            level = if (debug) HttpLoggingInterceptor.Level.BASIC else HttpLoggingInterceptor.Level.NONE
        }
        val client = OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .writeTimeout(20, TimeUnit.SECONDS)
            .callTimeout(30, TimeUnit.SECONDS)
            .addInterceptor(logging)
            .build()
        val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()
        return Retrofit.Builder().baseUrl(baseUrl).client(client)
            .addConverterFactory(MoshiConverterFactory.create(moshi)).build()
            .create(CbtApi::class.java)
    }
}
